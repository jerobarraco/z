#coding:utf-8

def parse_asm_line(r, lvl=0):
	print("inside asm_line")
	line = r.getTill("\n", True)
	print ("got asm line", repr(line))
	#global p
	#p.writeAsm(line)
	return line

def parse_asm(r, lvl =0):
	print("got an asm line buff is,",repr(r.l))
	mylvl = r.level
	print ("level is ", r.level)
	r.consume(list(" \n\t"))
	if not r.scan([":"], consume=True): Exception("no : after asm")
	r.consume(list(" \t"))
	r.consume(list("\n"))
	l = r.level
	print ("level is ", r.level)
	if l<=mylvl: 
		print("level is wrong, quit ", mylvl, l)
		return
	lines = []
	while r.level >mylvl :
		print("inside asm")
		lines.append(parse_asm_line(r, mylvl))
	return lines
