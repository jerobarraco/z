#coding:utf-8
from parsers import asm, fun

class Program:
	def __init__(self, f):
		self.f = f
	def writeAsm(self, l):
		self.f.write(l)
	def writeInst(self, ins):
		for i in ins:
			self.writeAsm(str(i))

class Reader:
	def __init__(self, f):
		self.f = f
		self.l = ""
		self.level = 0
		self.consume = self.getWhile#lazy refactor
		
	def _r(self, strip=False):
		#level and strip is so buggy, fix, create a separated function to consume data
		#calculate level after each consume
		print("reading")
		l = self.f.readline()
		level = 0
		#if (strip) and (l[-1]=="\n"): l = l[:-1]
		if l=="": 
			self.f.close()
			return
		
		while l[level]== "\t":
			level += 1
			
		if strip:
			l = l[level:]
			#strip empty line
			if l.strip() in ("", "\n"):
				l = ''
			
		print("readed final is", repr(l), "level", level)
		self.l += l
		self.level = level
		
		#skip empty lines
		if not l and not self.f.closed:
			self._r(strip)
		return level
	
	def scan(self, toks=[], consume=False, strip=True):
		if type(toks) == str: toks = list(toks)
		print("searching tokens=%s in s=%s"%(toks, repr(self.l)))
		toks.sort() # sorts normally by alphabetical order
		toks.sort(key=len)
		for k in toks:#sort, to avoid reading ahead if possible
			if len(k)>len(self.l):
				self._r(strip)
			if self.l.startswith(k):
				if consume:
					self.l = self.l[len(k):]
				return k
		return ""
	
	def getWhile(self, toks=[]):
		t = ""
		while True:
			tt = self.scan(toks, consume=True)
			if not tt: break
			t += tt
		print("consumed", repr(t))
		return t

	def getTill(self, toks=[], strip=False):
		while True:
			for i in toks:
				p = self.l.find(i)+1#notice +1
				if p>0:
					b = self.l[:p]
					self.l = self.l[p:]
					if not self.l:
						print("force reading ahead buffer empty")
						self._r(strip)
					return b

			if self.f.closed: return ""
			self._r(strip)
			
	def peek(self, count, strip=False): 
		if len(self.l) < count:
			self._r(strip)
		return self.l[:count]
	
	def gotStuff(self):
		return self.l or not self.f.closed

def parse_def(l):
	print ("stub")
	return ""

parse_struct = parse_const= parse_import = parse_def

__global_tokens = {
	"asm": asm.parse_asm,
	"fun": fun.parse_proc,
	"import": parse_import,
	"struct": parse_struct,
	"const":parse_const
}

def parse_global(r, lvl=0):
	"""search for global elements
	asm:
	proc:
	import stuff
	struct:
	const:
	"""
	t = r.scan(list(__global_tokens.keys()), consume=True, strip=True)
	if t not in __global_tokens:
		raise Exception("wtf? i don't know what to do, buffer is %s"%repr(r.l))
	instructions = []
	instructions.extend(
		__global_tokens[t](r)
	)
	return instructions

def parse(r, p):
	l = ""
	while r.gotStuff():
		instructions = parse_global(r)
		print ("level=%s  buff='%s'" %(r.level, repr(r.l)))
		for i in instructions:
			p.writeAsm(i)
