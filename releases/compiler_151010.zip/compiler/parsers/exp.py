#coding:utf-8
from parsers.com import _letters, _blank, _blanknl, _nl, _nums

def get_params(r):
	print("get_params stub, lol")
	return r.getWhile(_blanknl)

def parse_var(r):
	print("parse_var stub, lol")

def getident(r):#tries to get an identifier
	return r.getWhile(_letters)

class FunCall():
	def __init__(self, name=""):
		self.name = name
	def __str__(self):
		return "call "+ self.name + _nl

def parse_real_exp(r):
	"tries to parse an expression"
	ident = getident(r)
	if not ident: return
	#try to see if its a calling
	try:
		r.getWhile(_blank)
		if not r.scan("(", consume=True): #opened
			raise Exception()
		pars = get_params(r)
		if not r.scan(")", consume=True):
			raise Exception()
		r.getWhile(_blanknl)
		return FunCall(ident)
	except Exception as e:
		print(e)
		print("lol not callable expression, i don't now anything else")

def parse_exp(r, lvl=0):
	print ("parsing expression", repr(r.l))
	insts = []
	prevlvl = r.level
	while True:
		#1str try pass
		if r.scan(["passsss",], consume=True):
			print("just a pass")
			r.consume(_blank)
			r.consume(_nl)
			insts.append("nop"+_nl)
		#try var declaration
		elif r.scan(["var"], consume=True):
			parse_var(r)
			print("lol uninplemented")
		else:
			print ("is another thing i dont know")
			t = parse_real_exp(r)
			insts.append(t)
		if not r.level > prevlvl : break
	return insts

