#coding:utf-8
import string
__blank = " \t"
__nl = "\n"
__blanknl = __blank+__nl
_letters = string.ascii_letters
_nums = string.digits # hexdigits #octdigits
from parsers.exp import parse_exp

class Fun():
	insts = None
	name = ""
	def __init__(self):
		self.insts = []
		
	def __str__(self):
		lines = [
			str(i) for i in self.insts
		]
		if self.name == "main": self.name = "_start"
		lines.insert(0, self.name+":\n")
		lines.append("ret\n" )
		return "".join(lines)

def parse_proc(r, lvl=0):
	print("got a 'fun' line buff is", repr(r.l), "level is", repr(r.level))
	mylvl = r.level
	r.consume(__blank)
	name = r.getTill(" (:\n", True)
	print("myname is", repr(name))
	last = name[-1]
	if last == " ":
		pad = r.getTill("(:\n", True)
		if pad.strip() != "": raise Exception ("Expected '(' ")
	if last == "(": name = name[:-1]
	print("myname final is", repr(name))
	proc = Fun()
	proc.name = name.strip()
	r.consume(__blanknl)
	r.scan(")", True)
	r.consume(__blank)
	if not r.scan(":", consume=True ): Exception("Expected ':'")
	r.consume(list(" \t"))
	r.consume(list("\n"))
	l = r.level
	print ("level is ", r.level)
	
	if l<=mylvl: 
		print("level is wrong, quit")
		return
	from parsers import base
	while r.level >mylvl :
		try:
			proc.insts.extend(base.parse_global(r))
		except:
			#try instructions
			print("mylvl", mylvl, "lvl", r.level)
			res = parse_exp(r, mylvl)
			if res:
				proc.insts.extend(res)
			else:
				print("some instruction i dont understand")
	return str(proc)
