import string
_blank = " \t"
_nl = "\n"#fuck cross platform, mywayorthehighway
_blanknl = _blank+_nl

_letters = string.ascii_letters
_nums = string.digits
_hex = string.hexdigits
_oct = string.octdigits