	Z Compiler in Z
	Z Compiler in Python
		Better stream reader
			endline and tab managment. 
				Consume func
				level
				sorted by len scan
		Proc
			Instructions
				Variables
				Expressions
				Arguments
				Branch
				Loops
				
		Struct
			Types
			data structures
			metainfo
		Const
			data types
			