	Z Compiler in Z
	Z Compiler in Python
		Better stream reader
			endline and tab managment. 
				* Consume func (handle depletion, level, and in-place-strip)
				* scan
				* strip
				
				* level
				* sorted by len scan
		COMMENTS!!!! (one liners at least)
		Instructions
			Literas
			* Variables
			Expressions
				Assignment
				Boolean (for ifs)
				Math
			Functions
				* definition
				calling
					* basic
					Arguments*
					return values
			Branch
				If
			Loops
				While
				for
				
		Struct
			Types
			data structures
			metainfo
		Const
			data types
		Namespaces (honk honk cheen)