#coding:utf-8
from parsers.com import letters, blank, blanknl, nl, nums
from parsers import asm
class Basic:
	def __init__(self, name="", lvl=0):
		self.name = name
		self.l = lvl
		self.asm = []
	def __str__(self):
		return "".join(map(str, self.asm))

class FunCall:#todo move to fun?
	def __init__(self, name="", lvl=0):
		self.name = name
		self.l = lvl
		self.asm = asm.Asm("call "+name, lvl)

	def __str__(self):
		return str(self.asm)

class Var:
	def __init__(self, name="", val=0, t="int", lvl=0):
		self.name = name
		self.l = lvl
		self.v = val
		self.t = t
		if isinstance(t, Identifier):
			if not t.is_type :
				print ("the type is unknown:", t)
			t = str(t)
		if t == "int":
			self.asm = [ asm.Asm(str(name)+": db %s"%val, lvl), ]
		elif t == "str":
			val = str(val)
			self.asm = [
				asm.Asm(str(name)+": db '"+val+"',10", lvl),
				asm.Asm(str(name)+"Len: db %s"%len(val), lvl)
			]

	def __str__(self):
		return "".join(map(str, self.asm))

class Assign:
	def __init__(self, name="", lvl=0, val=""):
		self.name = name
		self.l = lvl
		if isinstance(val, Identifier) or isinstance(val, int):
			val = str(val)
		self.v = val
		self.asm = [asm.Asm("mov " +name+", "+val, lvl)]
	def __str__(self):
		return "".join(map(str, self.asm))

class Identifier:
	def __init__(self, name="", lvl=0):
		self.n = name
		self.l = lvl
		self.is_type = name in ("int", "str", "byte", "char")

	def __str__(self):
		return self.n
		#return asm.Asm(self.n, self.l)

	def tryCall(self, r):
		try:
			r.getWhile(blank)
			if not r.get("("): #opened
				raise Exception("Expected (, not a function call")
			pars = get_params(r)
			print ("Params are ", list(map(str, pars)))
			if not r.get(")"):
				raise Exception("Expected )")
			r.getWhile(blank)
			r.getWhile(nl)
			return FunCall(str(self), self.l)
		except Exception as e:
			print(e)
			print("lol not callable expression, i don't now anything else")
		return None

	def tryLen(self, r): pass
	def tryMath(self, r): pass #this probably needs to call parse_real_exp
	def tryCmp(self, r): pass
	def trySet(self, r):
		r.lstrip(True)
		if not r.get("="): return
		#todo parse_true_real_exp
		r.lstrip(True)
		i = getident(r)
		if not i:
			i = r.getWhile(nums) #todo getNum
		return Assign(self.name, self.l, i)


def get_params(r):
	print("get_params stub, lol")
	ps = []
	while True:
		r.lstrip(True)
		i = getident(r)
		if not i: break
		ps.append(i)
		r.lstrip(True)
		r.getWhile(",")
	return ps

def getident(r, lvl=0):#tries to get an identifier
	i = r.getWhile(letters)
	if i :
		return Identifier(i, lvl)
	return

def parse_var(r, lvl=0):
	"""tries to parse a variable definiton"""
	#todo add to class? as "try to"
	r.getWhile(blank)
	taip = getident(r)
	if not taip: return

	r.getWhile(blank)
	name = getident(r, lvl)
	if not name : raise Exception("expected name")
	r.getWhile(blank)
	val = 0
	eq = r.get("=")
	if eq:
		r.getWhile(blank)
		tn = str(taip)
		if tn == "str":
			if not r.get('"'): raise Exception("expected \"")
			val = r.getTill(['"'])
			if val[-1] == '"' : val = val[:-1]
		elif tn == "int":
			val = r.getWhile(nums) or 0
	v = Var(name, val, taip, lvl )
	return str(v)#para sacar cuando saque los vars a los funcs


def parse_real_exp(r, lvl=0):
	"tries to parse an expression"
	#TODO this will need major refactoring when the expressions are done
	r.getWhile(blank)
	ident = getident(r, lvl)
	if not ident: return
	#try to see if its a calling
	for act in (ident.trySet, ident.tryCall, ident.tryLen, ident.trySet,
				ident.tryMath, ident.tryCmp):
		ret = act(r)
		if ret : return ret

def parse_exp(r, lvl=0): #expressions are separated by \n so one liners here only, level cares not
	print ("parsing expression", repr(r.l))
	insts = []
	r.getWhile(blank)
	#1str try pass
	if r.get(["passsss",]):
		print("just a pass")
		insts.append((r.lvl*"\t")+"nop"+nl)
		r.getWhile(blank)
		r.getWhile(nl)
	#try var declaration
	#todo remove "var"
	elif r.get(["var"]):
		parse_var(r)
	else:
		print ("is another thing i dont know")
		t = parse_real_exp(r, lvl)
		insts.append(t)
	return insts

