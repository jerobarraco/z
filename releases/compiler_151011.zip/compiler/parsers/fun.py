#coding:utf-8
from parsers import com, asm, exp

class Exit:
	def __init__(self, c=0, l=0):
		self.c = c
		self.l = l
		s = [	";exiting!",
			 	"mov eax, 1",
			 	"mov ebx, %s"%self.c,
			 	"int 80h;byebyecruelworld",
				""]
		self.asms = [ asm.Asm(i, l) for i in s ]

	def __str__(self):
		return "".join(map(str, self.asms))

class Fun:
	insts = None
	name = ""
	def __init__(self, name="", l=0):
		self.insts = []
		self.l = l
		if name == "main": name = "_start" #TODO fix
		self.name = name
		
	def __str__(self):
		lines = ["\n"+self.name+":\n",]
		lines.extend([
			str(i) for i in self.insts
		])

		if self.name == "_start":
			lines.append(str(Exit(0, self.l)))
		else:
			lines.append("ret\n" )
		lines.append("\n")
		return "".join(lines)

def parse_proc(r, lvl=0):
	print("got a 'fun' line buff is", repr(r.l), "level is", repr(r.level))
	mylvl = lvl
	r.getWhile(com.blank)
	name = r.getWhile(com.letters)
	#name = r._getTill(" (:\n")#TODO this whill consume extra chars between funcname and (
	r.getWhile(com.blank)
	if not r.get("("): raise Exception ("Expected '(' ")
	print("myname is", repr(name))
	r.getWhile(com.blank)
	if not r.get(")"):
		raise Exception("Expected )")
	r.getWhile(com.blank)
	if not r.get(":"):
		Exception("Expected ':'")
	r.getWhile(com.blank)
	r.getWhile(com.nl)
	l = r.level
	proc = Fun(name, l)
	print ("level is ", r.level)

	if l<=mylvl:
		print("level is wrong, quit")
		return
	from parsers import base
	while r.level >mylvl :
		r.stripBlankLines()
		try:
			proc.insts.extend(base.parse_global(r))
		except Exception as e:
			#try instructions
			print("mylvl", mylvl, "lvl", r.level)
			res = exp.parse_exp(r, r.level)
			if res:
				proc.insts.extend(res)
			else:
				print("some instruction i dont understand")
	return str(proc)
