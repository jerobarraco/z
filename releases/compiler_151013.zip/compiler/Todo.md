	Z Compiler in Z
	Z Compiler in Python
		Better stream reader
			endline and tab managment. 
				* Consume func (handle depletion, level, and in-place-strip)
				* scan
				* strip
				* level
				* sorted by len scan
			new flow
				1) change multiline expressions to oneliners
					( strings, parenthesis, enums, math)
				2) divide blocks
				3) parse block identifier
				4) Mark module as loaded, import other modules
				3) parse blocks
				4) asm-fi
			
		COMMENTS!!!! (one liners at least)
		Instructions
			Literas
			* Variables
			Expressions
				Assignment
				Boolean (for ifs)
				Math
			Functions
				* definition
				calling
					* basic
					Arguments
						* detect
						* pass
					return values
			Branch
				If
			Loops
				While
				for
				
		Struct
			Types
			data structures
			metainfo
		Const
			data types
		Namespaces (honk honk cheen)