import string
blank = " \t"
nl = "\n"#fuck cross platform, mywayorthehighway
blanknl = blank+nl
main_name = "_start"
letters = string.ascii_letters + "_"
nums = string.digits
hex = string.hexdigits
oct = string.octdigits